﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaLogic;

namespace ComiqueriaApp
{
    public partial class VentasForm : Form
    {
        Producto p;

        public VentasForm(Producto productoSeleccionado, Comiqueria comiqueria)
        {
            InitializeComponent();
            lblDescripcion.Text = productoSeleccionado.Descripcion;
            p = productoSeleccionado;
        }

        private void VentasForm_Load(object sender, EventArgs e)
        {
            
        }

        private void numericUpDownCantidad_ValueChanged(object sender, EventArgs e)
        {
           
            //lblCantidad.Text(String.Format("Precio Final: {0}", p.Precio * (double)numericUpDownCantidad.Value));
            lblCantidad.ResetText();
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblDescripcion_Click(object sender, EventArgs e)
        {
          
        }
    }
}
